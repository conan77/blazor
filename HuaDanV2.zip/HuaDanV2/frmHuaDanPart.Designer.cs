﻿namespace HuaDan
{
	partial class frmHuaDanPart
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label3 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panBtnOuter = new System.Windows.Forms.Panel();
			this.panBtn4 = new System.Windows.Forms.Panel();
			this.btnHuaDan = new System.Windows.Forms.Button();
			this.btn0 = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.panBtn3 = new System.Windows.Forms.Panel();
			this.btn9 = new System.Windows.Forms.Button();
			this.btn8 = new System.Windows.Forms.Button();
			this.btn7 = new System.Windows.Forms.Button();
			this.panBtn2 = new System.Windows.Forms.Panel();
			this.btn6 = new System.Windows.Forms.Button();
			this.btn5 = new System.Windows.Forms.Button();
			this.btn4 = new System.Windows.Forms.Button();
			this.panBtn1 = new System.Windows.Forms.Panel();
			this.btn3 = new System.Windows.Forms.Button();
			this.btn2 = new System.Windows.Forms.Button();
			this.btn1 = new System.Windows.Forms.Button();
			this.txtLeftNum = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.lblDishName = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtNum = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel1.SuspendLayout();
			this.panBtnOuter.SuspendLayout();
			this.panBtn4.SuspendLayout();
			this.panBtn3.SuspendLayout();
			this.panBtn2.SuspendLayout();
			this.panBtn1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::HuaDan.Properties.Resources.close;
			this.pictureBox1.Location = new System.Drawing.Point(404, 17);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(30, 30);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 8;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(12, 17);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 25);
			this.label3.TabIndex = 7;
			this.label3.Tag = "";
			this.label3.Text = "部分划单";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.Add(this.txtNum);
			this.panel1.Controls.Add(this.txtLeftNum);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.panBtnOuter);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.lblDishName);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(15, 53);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(419, 446);
			this.panel1.TabIndex = 9;
			// 
			// panBtnOuter
			// 
			this.panBtnOuter.Controls.Add(this.panBtn4);
			this.panBtnOuter.Controls.Add(this.panBtn3);
			this.panBtnOuter.Controls.Add(this.panBtn2);
			this.panBtnOuter.Controls.Add(this.panBtn1);
			this.panBtnOuter.Location = new System.Drawing.Point(27, 148);
			this.panBtnOuter.Name = "panBtnOuter";
			this.panBtnOuter.Size = new System.Drawing.Size(360, 280);
			this.panBtnOuter.TabIndex = 4;
			// 
			// panBtn4
			// 
			this.panBtn4.Controls.Add(this.btnHuaDan);
			this.panBtn4.Controls.Add(this.btn0);
			this.panBtn4.Controls.Add(this.btnClear);
			this.panBtn4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panBtn4.Location = new System.Drawing.Point(0, 210);
			this.panBtn4.Name = "panBtn4";
			this.panBtn4.Size = new System.Drawing.Size(360, 70);
			this.panBtn4.TabIndex = 3;
			// 
			// btnHuaDan
			// 
			this.btnHuaDan.Dock = System.Windows.Forms.DockStyle.Left;
			this.btnHuaDan.Font = new System.Drawing.Font("微软雅黑", 13F);
			this.btnHuaDan.Location = new System.Drawing.Point(240, 0);
			this.btnHuaDan.Name = "btnHuaDan";
			this.btnHuaDan.Size = new System.Drawing.Size(120, 70);
			this.btnHuaDan.TabIndex = 12;
			this.btnHuaDan.Text = "划单";
			this.btnHuaDan.UseVisualStyleBackColor = true;
			this.btnHuaDan.Click += new System.EventHandler(this.btnHuaDan_Click);
			// 
			// btn0
			// 
			this.btn0.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn0.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn0.Location = new System.Drawing.Point(120, 0);
			this.btn0.Name = "btn0";
			this.btn0.Size = new System.Drawing.Size(120, 70);
			this.btn0.TabIndex = 11;
			this.btn0.Text = "0";
			this.btn0.UseVisualStyleBackColor = true;
			this.btn0.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btnClear
			// 
			this.btnClear.Dock = System.Windows.Forms.DockStyle.Left;
			this.btnClear.Font = new System.Drawing.Font("微软雅黑", 13F);
			this.btnClear.Location = new System.Drawing.Point(0, 0);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(120, 70);
			this.btnClear.TabIndex = 10;
			this.btnClear.Text = "清空";
			this.btnClear.UseVisualStyleBackColor = true;
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// panBtn3
			// 
			this.panBtn3.Controls.Add(this.btn9);
			this.panBtn3.Controls.Add(this.btn8);
			this.panBtn3.Controls.Add(this.btn7);
			this.panBtn3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panBtn3.Location = new System.Drawing.Point(0, 140);
			this.panBtn3.Name = "panBtn3";
			this.panBtn3.Size = new System.Drawing.Size(360, 70);
			this.panBtn3.TabIndex = 2;
			// 
			// btn9
			// 
			this.btn9.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn9.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn9.Location = new System.Drawing.Point(240, 0);
			this.btn9.Name = "btn9";
			this.btn9.Size = new System.Drawing.Size(120, 70);
			this.btn9.TabIndex = 11;
			this.btn9.Text = "9";
			this.btn9.UseVisualStyleBackColor = true;
			this.btn9.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn8
			// 
			this.btn8.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn8.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn8.Location = new System.Drawing.Point(120, 0);
			this.btn8.Name = "btn8";
			this.btn8.Size = new System.Drawing.Size(120, 70);
			this.btn8.TabIndex = 10;
			this.btn8.Text = "8";
			this.btn8.UseVisualStyleBackColor = true;
			this.btn8.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn7
			// 
			this.btn7.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn7.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn7.Location = new System.Drawing.Point(0, 0);
			this.btn7.Name = "btn7";
			this.btn7.Size = new System.Drawing.Size(120, 70);
			this.btn7.TabIndex = 9;
			this.btn7.Text = "7";
			this.btn7.UseVisualStyleBackColor = true;
			this.btn7.Click += new System.EventHandler(this.btn1_Click);
			// 
			// panBtn2
			// 
			this.panBtn2.Controls.Add(this.btn6);
			this.panBtn2.Controls.Add(this.btn5);
			this.panBtn2.Controls.Add(this.btn4);
			this.panBtn2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panBtn2.Location = new System.Drawing.Point(0, 70);
			this.panBtn2.Name = "panBtn2";
			this.panBtn2.Size = new System.Drawing.Size(360, 70);
			this.panBtn2.TabIndex = 1;
			// 
			// btn6
			// 
			this.btn6.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn6.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn6.Location = new System.Drawing.Point(240, 0);
			this.btn6.Name = "btn6";
			this.btn6.Size = new System.Drawing.Size(120, 70);
			this.btn6.TabIndex = 10;
			this.btn6.Text = "6";
			this.btn6.UseVisualStyleBackColor = true;
			this.btn6.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn5
			// 
			this.btn5.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn5.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn5.Location = new System.Drawing.Point(120, 0);
			this.btn5.Name = "btn5";
			this.btn5.Size = new System.Drawing.Size(120, 70);
			this.btn5.TabIndex = 9;
			this.btn5.Text = "5";
			this.btn5.UseVisualStyleBackColor = true;
			this.btn5.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn4
			// 
			this.btn4.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn4.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn4.Location = new System.Drawing.Point(0, 0);
			this.btn4.Name = "btn4";
			this.btn4.Size = new System.Drawing.Size(120, 70);
			this.btn4.TabIndex = 8;
			this.btn4.Text = "4";
			this.btn4.UseVisualStyleBackColor = true;
			this.btn4.Click += new System.EventHandler(this.btn1_Click);
			// 
			// panBtn1
			// 
			this.panBtn1.Controls.Add(this.btn3);
			this.panBtn1.Controls.Add(this.btn2);
			this.panBtn1.Controls.Add(this.btn1);
			this.panBtn1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panBtn1.Location = new System.Drawing.Point(0, 0);
			this.panBtn1.Name = "panBtn1";
			this.panBtn1.Size = new System.Drawing.Size(360, 70);
			this.panBtn1.TabIndex = 0;
			// 
			// btn3
			// 
			this.btn3.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn3.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn3.Location = new System.Drawing.Point(240, 0);
			this.btn3.Name = "btn3";
			this.btn3.Size = new System.Drawing.Size(120, 70);
			this.btn3.TabIndex = 9;
			this.btn3.Text = "3";
			this.btn3.UseVisualStyleBackColor = true;
			this.btn3.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn2
			// 
			this.btn2.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn2.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn2.Location = new System.Drawing.Point(120, 0);
			this.btn2.Name = "btn2";
			this.btn2.Size = new System.Drawing.Size(120, 70);
			this.btn2.TabIndex = 8;
			this.btn2.Text = "2";
			this.btn2.UseVisualStyleBackColor = true;
			this.btn2.Click += new System.EventHandler(this.btn1_Click);
			// 
			// btn1
			// 
			this.btn1.Dock = System.Windows.Forms.DockStyle.Left;
			this.btn1.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.btn1.Location = new System.Drawing.Point(0, 0);
			this.btn1.Name = "btn1";
			this.btn1.Size = new System.Drawing.Size(120, 70);
			this.btn1.TabIndex = 7;
			this.btn1.Text = "1";
			this.btn1.UseVisualStyleBackColor = true;
			this.btn1.Click += new System.EventHandler(this.btn1_Click);
			// 
			// txtLeftNum
			// 
			this.txtLeftNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtLeftNum.Font = new System.Drawing.Font("微软雅黑", 14F);
			this.txtLeftNum.Location = new System.Drawing.Point(128, 60);
			this.txtLeftNum.MaxLength = 10000;
			this.txtLeftNum.Name = "txtLeftNum";
			this.txtLeftNum.ReadOnly = true;
			this.txtLeftNum.Size = new System.Drawing.Size(191, 32);
			this.txtLeftNum.TabIndex = 0;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.label4.Location = new System.Drawing.Point(30, 60);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(97, 27);
			this.label4.TabIndex = 2;
			this.label4.Text = "剩余数量:";
			// 
			// lblDishName
			// 
			this.lblDishName.AutoSize = true;
			this.lblDishName.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.lblDishName.Location = new System.Drawing.Point(123, 23);
			this.lblDishName.Name = "lblDishName";
			this.lblDishName.Size = new System.Drawing.Size(132, 27);
			this.lblDishName.TabIndex = 1;
			this.lblDishName.Text = "西红柿炒番茄";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.label1.Location = new System.Drawing.Point(30, 23);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(57, 27);
			this.label1.TabIndex = 0;
			this.label1.Text = "品名:";
			// 
			// txtNum
			// 
			this.txtNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtNum.Font = new System.Drawing.Font("微软雅黑", 14F);
			this.txtNum.Location = new System.Drawing.Point(128, 103);
			this.txtNum.MaxLength = 10000;
			this.txtNum.Name = "txtNum";
			this.txtNum.Size = new System.Drawing.Size(191, 32);
			this.txtNum.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("微软雅黑", 15F);
			this.label2.Location = new System.Drawing.Point(30, 101);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(57, 27);
			this.label2.TabIndex = 5;
			this.label2.Text = "数量:";
			// 
			// frmHuaDanPart
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Teal;
			this.ClientSize = new System.Drawing.Size(451, 519);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.label3);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmHuaDanPart";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "部分划单";
			this.Resize += new System.EventHandler(this.frmHuaDanPart_Resize);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panBtnOuter.ResumeLayout(false);
			this.panBtn4.ResumeLayout(false);
			this.panBtn3.ResumeLayout(false);
			this.panBtn2.ResumeLayout(false);
			this.panBtn1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblDishName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtLeftNum;
		private System.Windows.Forms.Panel panBtnOuter;
		private System.Windows.Forms.Panel panBtn1;
		private System.Windows.Forms.Panel panBtn2;
		private System.Windows.Forms.Panel panBtn4;
		private System.Windows.Forms.Panel panBtn3;
		private System.Windows.Forms.Button btnHuaDan;
		private System.Windows.Forms.Button btn0;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btn9;
		private System.Windows.Forms.Button btn8;
		private System.Windows.Forms.Button btn7;
		private System.Windows.Forms.Button btn6;
		private System.Windows.Forms.Button btn5;
		private System.Windows.Forms.Button btn4;
		private System.Windows.Forms.Button btn3;
		private System.Windows.Forms.Button btn2;
		private System.Windows.Forms.Button btn1;
		private System.Windows.Forms.TextBox txtNum;
		private System.Windows.Forms.Label label2;
	}
}