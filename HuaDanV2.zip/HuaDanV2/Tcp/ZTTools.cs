﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HuaDan
{
    /// <summary>
    /// 缓存桌台---用于叫号
    /// </summary>
    public class ZTTools
    {
       /// <summary>
       /// OrderZhuoTai | HisOrderZhuoTai 表的主键UID
       /// </summary>
        public static List<string> ZhuoTaiUIDList;
    }
}
