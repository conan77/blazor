﻿namespace HuaDan
{
    partial class frmZTDish
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmZTDish));
			this.panTop = new System.Windows.Forms.Panel();
			this.panLeft = new System.Windows.Forms.Panel();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.panZTBottom = new System.Windows.Forms.Panel();
			this.btnAllZhuoTai = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnZTDown = new System.Windows.Forms.Button();
			this.btnZTUp = new System.Windows.Forms.Button();
			this.panRightBottom = new System.Windows.Forms.Panel();
			this.btnTJ = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.btnGuQingList = new System.Windows.Forms.Button();
			this.btnDown = new System.Windows.Forms.Button();
			this.btnUp = new System.Windows.Forms.Button();
			this.txtHuaCaiNum = new System.Windows.Forms.TextBox();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.btnSetup = new System.Windows.Forms.Button();
			this.panRightTop = new System.Windows.Forms.Panel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.btnZTHuaDan = new System.Windows.Forms.Button();
			this.panLeft.SuspendLayout();
			this.panZTBottom.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panRightBottom.SuspendLayout();
			this.panRightTop.SuspendLayout();
			this.SuspendLayout();
			// 
			// panTop
			// 
			this.panTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.panTop.Location = new System.Drawing.Point(0, 0);
			this.panTop.Name = "panTop";
			this.panTop.Size = new System.Drawing.Size(939, 0);
			this.panTop.TabIndex = 0;
			// 
			// panLeft
			// 
			this.panLeft.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.panLeft.Controls.Add(this.tableLayoutPanel1);
			this.panLeft.Controls.Add(this.panZTBottom);
			this.panLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.panLeft.Location = new System.Drawing.Point(0, 0);
			this.panLeft.Name = "panLeft";
			this.panLeft.Size = new System.Drawing.Size(194, 528);
			this.panLeft.TabIndex = 1;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.DimGray;
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 20;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(194, 452);
			this.tableLayoutPanel1.TabIndex = 1;
			// 
			// panZTBottom
			// 
			this.panZTBottom.BackColor = System.Drawing.SystemColors.Control;
			this.panZTBottom.Controls.Add(this.btnAllZhuoTai);
			this.panZTBottom.Controls.Add(this.panel1);
			this.panZTBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panZTBottom.Location = new System.Drawing.Point(0, 452);
			this.panZTBottom.Name = "panZTBottom";
			this.panZTBottom.Size = new System.Drawing.Size(194, 76);
			this.panZTBottom.TabIndex = 0;
			// 
			// btnAllZhuoTai
			// 
			this.btnAllZhuoTai.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btnAllZhuoTai.FlatAppearance.BorderSize = 0;
			this.btnAllZhuoTai.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnAllZhuoTai.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnAllZhuoTai.Location = new System.Drawing.Point(0, 38);
			this.btnAllZhuoTai.Name = "btnAllZhuoTai";
			this.btnAllZhuoTai.Size = new System.Drawing.Size(194, 38);
			this.btnAllZhuoTai.TabIndex = 3;
			this.btnAllZhuoTai.Text = "全部桌台";
			this.btnAllZhuoTai.UseVisualStyleBackColor = true;
			this.btnAllZhuoTai.Click += new System.EventHandler(this.btnAllZhuoTai_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btnZTDown);
			this.panel1.Controls.Add(this.btnZTUp);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(194, 38);
			this.panel1.TabIndex = 2;
			// 
			// btnZTDown
			// 
			this.btnZTDown.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btnZTDown.FlatAppearance.BorderSize = 0;
			this.btnZTDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnZTDown.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnZTDown.Location = new System.Drawing.Point(98, 0);
			this.btnZTDown.Name = "btnZTDown";
			this.btnZTDown.Size = new System.Drawing.Size(96, 38);
			this.btnZTDown.TabIndex = 1;
			this.btnZTDown.Text = "下一页";
			this.btnZTDown.UseVisualStyleBackColor = true;
			this.btnZTDown.Click += new System.EventHandler(this.btnZTDown_Click);
			// 
			// btnZTUp
			// 
			this.btnZTUp.Dock = System.Windows.Forms.DockStyle.Left;
			this.btnZTUp.FlatAppearance.BorderSize = 0;
			this.btnZTUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnZTUp.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnZTUp.Location = new System.Drawing.Point(0, 0);
			this.btnZTUp.Name = "btnZTUp";
			this.btnZTUp.Size = new System.Drawing.Size(98, 38);
			this.btnZTUp.TabIndex = 0;
			this.btnZTUp.Text = "上一页";
			this.btnZTUp.UseVisualStyleBackColor = true;
			this.btnZTUp.Click += new System.EventHandler(this.btnZTUp_Click);
			// 
			// panRightBottom
			// 
			this.panRightBottom.BackColor = System.Drawing.SystemColors.Control;
			this.panRightBottom.Controls.Add(this.btnZTHuaDan);
			this.panRightBottom.Controls.Add(this.btnTJ);
			this.panRightBottom.Controls.Add(this.button1);
			this.panRightBottom.Controls.Add(this.btnGuQingList);
			this.panRightBottom.Controls.Add(this.btnDown);
			this.panRightBottom.Controls.Add(this.btnUp);
			this.panRightBottom.Controls.Add(this.txtHuaCaiNum);
			this.panRightBottom.Controls.Add(this.btnRefresh);
			this.panRightBottom.Controls.Add(this.btnSetup);
			this.panRightBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panRightBottom.Location = new System.Drawing.Point(194, 470);
			this.panRightBottom.Name = "panRightBottom";
			this.panRightBottom.Size = new System.Drawing.Size(745, 58);
			this.panRightBottom.TabIndex = 2;
			// 
			// btnTJ
			// 
			this.btnTJ.Font = new System.Drawing.Font("宋体", 10.71429F, System.Drawing.FontStyle.Bold);
			this.btnTJ.ForeColor = System.Drawing.Color.Red;
			this.btnTJ.Location = new System.Drawing.Point(434, 3);
			this.btnTJ.Margin = new System.Windows.Forms.Padding(2);
			this.btnTJ.Name = "btnTJ";
			this.btnTJ.Size = new System.Drawing.Size(77, 52);
			this.btnTJ.TabIndex = 13;
			this.btnTJ.Text = "统计";
			this.btnTJ.UseVisualStyleBackColor = true;
			this.btnTJ.Click += new System.EventHandler(this.btnTJ_Click);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("宋体", 10.71429F, System.Drawing.FontStyle.Bold);
			this.button1.ForeColor = System.Drawing.Color.Red;
			this.button1.Location = new System.Drawing.Point(353, 3);
			this.button1.Margin = new System.Windows.Forms.Padding(2);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(77, 52);
			this.button1.TabIndex = 12;
			this.button1.Text = "查询";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnGuQingList
			// 
			this.btnGuQingList.Font = new System.Drawing.Font("宋体", 10.71429F, System.Drawing.FontStyle.Bold);
			this.btnGuQingList.ForeColor = System.Drawing.Color.Red;
			this.btnGuQingList.Location = new System.Drawing.Point(5, 3);
			this.btnGuQingList.Margin = new System.Windows.Forms.Padding(2);
			this.btnGuQingList.Name = "btnGuQingList";
			this.btnGuQingList.Size = new System.Drawing.Size(90, 52);
			this.btnGuQingList.TabIndex = 11;
			this.btnGuQingList.Text = "沽清列表";
			this.btnGuQingList.UseVisualStyleBackColor = true;
			this.btnGuQingList.Click += new System.EventHandler(this.btnGuQingList_Click);
			// 
			// btnDown
			// 
			this.btnDown.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnDown.Location = new System.Drawing.Point(272, 3);
			this.btnDown.Margin = new System.Windows.Forms.Padding(2);
			this.btnDown.Name = "btnDown";
			this.btnDown.Size = new System.Drawing.Size(77, 52);
			this.btnDown.TabIndex = 10;
			this.btnDown.Text = "下一页";
			this.btnDown.UseVisualStyleBackColor = true;
			this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
			// 
			// btnUp
			// 
			this.btnUp.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnUp.Location = new System.Drawing.Point(191, 3);
			this.btnUp.Margin = new System.Windows.Forms.Padding(2);
			this.btnUp.Name = "btnUp";
			this.btnUp.Size = new System.Drawing.Size(77, 52);
			this.btnUp.TabIndex = 9;
			this.btnUp.Text = "上一页";
			this.btnUp.UseVisualStyleBackColor = true;
			this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
			// 
			// txtHuaCaiNum
			// 
			this.txtHuaCaiNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.txtHuaCaiNum.Font = new System.Drawing.Font("宋体", 15.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.txtHuaCaiNum.Location = new System.Drawing.Point(449, 15);
			this.txtHuaCaiNum.Margin = new System.Windows.Forms.Padding(2);
			this.txtHuaCaiNum.Name = "txtHuaCaiNum";
			this.txtHuaCaiNum.Size = new System.Drawing.Size(130, 32);
			this.txtHuaCaiNum.TabIndex = 8;
			this.txtHuaCaiNum.Click += new System.EventHandler(this.txtHuaCaiNum_Click);
			this.txtHuaCaiNum.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtHuaCaiNum_KeyDown);
			this.txtHuaCaiNum.Leave += new System.EventHandler(this.txtHuaCaiNum_Leave);
			// 
			// btnRefresh
			// 
			this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnRefresh.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnRefresh.Location = new System.Drawing.Point(584, 4);
			this.btnRefresh.Margin = new System.Windows.Forms.Padding(2);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(77, 52);
			this.btnRefresh.TabIndex = 7;
			this.btnRefresh.Text = "刷新";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// btnSetup
			// 
			this.btnSetup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSetup.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnSetup.Location = new System.Drawing.Point(666, 4);
			this.btnSetup.Margin = new System.Windows.Forms.Padding(2);
			this.btnSetup.Name = "btnSetup";
			this.btnSetup.Size = new System.Drawing.Size(77, 52);
			this.btnSetup.TabIndex = 6;
			this.btnSetup.Text = "设置";
			this.btnSetup.UseVisualStyleBackColor = true;
			this.btnSetup.Click += new System.EventHandler(this.btnSetup_Click);
			// 
			// panRightTop
			// 
			this.panRightTop.Controls.Add(this.tableLayoutPanel2);
			this.panRightTop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panRightTop.Location = new System.Drawing.Point(194, 0);
			this.panRightTop.Name = "panRightTop";
			this.panRightTop.Size = new System.Drawing.Size(745, 470);
			this.panRightTop.TabIndex = 3;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.tableLayoutPanel2.ColumnCount = 10;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 10;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(745, 470);
			this.tableLayoutPanel2.TabIndex = 0;
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 15000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// btnZTHuaDan
			// 
			this.btnZTHuaDan.Font = new System.Drawing.Font("宋体", 10.71429F, System.Drawing.FontStyle.Bold);
			this.btnZTHuaDan.ForeColor = System.Drawing.Color.Red;
			this.btnZTHuaDan.Location = new System.Drawing.Point(98, 3);
			this.btnZTHuaDan.Margin = new System.Windows.Forms.Padding(2);
			this.btnZTHuaDan.Name = "btnZTHuaDan";
			this.btnZTHuaDan.Size = new System.Drawing.Size(90, 52);
			this.btnZTHuaDan.TabIndex = 14;
			this.btnZTHuaDan.Text = "整桌划单";
			this.btnZTHuaDan.UseVisualStyleBackColor = true;
			this.btnZTHuaDan.Click += new System.EventHandler(this.btnZTHuaDan_Click);
			// 
			// frmZTDish
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.ClientSize = new System.Drawing.Size(939, 528);
			this.Controls.Add(this.panRightTop);
			this.Controls.Add(this.panRightBottom);
			this.Controls.Add(this.panLeft);
			this.Controls.Add(this.panTop);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmZTDish";
			this.Text = "划单";
			this.MaximumSizeChanged += new System.EventHandler(this.frmZTDish_MaximumSizeChanged);
			this.MinimumSizeChanged += new System.EventHandler(this.frmZTDish_MaximumSizeChanged);
			this.Load += new System.EventHandler(this.frmZTDish_Load);
			this.SizeChanged += new System.EventHandler(this.frmZTDish_MaximumSizeChanged);
			this.panLeft.ResumeLayout(false);
			this.panZTBottom.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panRightBottom.ResumeLayout(false);
			this.panRightBottom.PerformLayout();
			this.panRightTop.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panTop;
        private System.Windows.Forms.Panel panLeft;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panZTBottom;
        private System.Windows.Forms.Panel panRightBottom;
        private System.Windows.Forms.Panel panRightTop;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnZTDown;
        private System.Windows.Forms.Button btnZTUp;
        private System.Windows.Forms.TextBox txtHuaCaiNum;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSetup;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnGuQingList;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnAllZhuoTai;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTJ;
		private System.Windows.Forms.Button btnZTHuaDan;
    }
}