﻿namespace HuaDan
{
	partial class frmZhuoTaiQuery
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmZhuoTaiQuery));
			this.panLeftOuter = new System.Windows.Forms.Panel();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.panLeftBtn = new System.Windows.Forms.Panel();
			this.btnZTDown = new System.Windows.Forms.Button();
			this.btnZTUp = new System.Windows.Forms.Button();
			this.panBottom = new System.Windows.Forms.Panel();
			this.btnUp = new System.Windows.Forms.Button();
			this.btnDown = new System.Windows.Forms.Button();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.panLeftOuter.SuspendLayout();
			this.panLeftBtn.SuspendLayout();
			this.panBottom.SuspendLayout();
			this.SuspendLayout();
			// 
			// panLeftOuter
			// 
			this.panLeftOuter.Controls.Add(this.tableLayoutPanel1);
			this.panLeftOuter.Controls.Add(this.panLeftBtn);
			this.panLeftOuter.Dock = System.Windows.Forms.DockStyle.Left;
			this.panLeftOuter.Location = new System.Drawing.Point(0, 0);
			this.panLeftOuter.Name = "panLeftOuter";
			this.panLeftOuter.Size = new System.Drawing.Size(200, 617);
			this.panLeftOuter.TabIndex = 0;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.DimGray;
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 20;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 569);
			this.tableLayoutPanel1.TabIndex = 2;
			// 
			// panLeftBtn
			// 
			this.panLeftBtn.Controls.Add(this.btnZTDown);
			this.panLeftBtn.Controls.Add(this.btnZTUp);
			this.panLeftBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panLeftBtn.Location = new System.Drawing.Point(0, 569);
			this.panLeftBtn.Name = "panLeftBtn";
			this.panLeftBtn.Size = new System.Drawing.Size(200, 48);
			this.panLeftBtn.TabIndex = 0;
			// 
			// btnZTDown
			// 
			this.btnZTDown.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btnZTDown.FlatAppearance.BorderSize = 0;
			this.btnZTDown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnZTDown.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnZTDown.Location = new System.Drawing.Point(98, 0);
			this.btnZTDown.Name = "btnZTDown";
			this.btnZTDown.Size = new System.Drawing.Size(102, 48);
			this.btnZTDown.TabIndex = 3;
			this.btnZTDown.Text = "下一页";
			this.btnZTDown.UseVisualStyleBackColor = true;
			this.btnZTDown.Click += new System.EventHandler(this.btnZTDown_Click);
			// 
			// btnZTUp
			// 
			this.btnZTUp.Dock = System.Windows.Forms.DockStyle.Left;
			this.btnZTUp.FlatAppearance.BorderSize = 0;
			this.btnZTUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnZTUp.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnZTUp.Location = new System.Drawing.Point(0, 0);
			this.btnZTUp.Name = "btnZTUp";
			this.btnZTUp.Size = new System.Drawing.Size(98, 48);
			this.btnZTUp.TabIndex = 2;
			this.btnZTUp.Text = "上一页";
			this.btnZTUp.UseVisualStyleBackColor = true;
			this.btnZTUp.Click += new System.EventHandler(this.btnZTUp_Click);
			// 
			// panBottom
			// 
			this.panBottom.Controls.Add(this.btnUp);
			this.panBottom.Controls.Add(this.btnDown);
			this.panBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panBottom.Location = new System.Drawing.Point(200, 569);
			this.panBottom.Name = "panBottom";
			this.panBottom.Size = new System.Drawing.Size(680, 48);
			this.panBottom.TabIndex = 1;
			// 
			// btnUp
			// 
			this.btnUp.Dock = System.Windows.Forms.DockStyle.Right;
			this.btnUp.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnUp.Location = new System.Drawing.Point(526, 0);
			this.btnUp.Margin = new System.Windows.Forms.Padding(2);
			this.btnUp.Name = "btnUp";
			this.btnUp.Size = new System.Drawing.Size(77, 48);
			this.btnUp.TabIndex = 13;
			this.btnUp.Text = "上一页";
			this.btnUp.UseVisualStyleBackColor = true;
			this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
			// 
			// btnDown
			// 
			this.btnDown.Dock = System.Windows.Forms.DockStyle.Right;
			this.btnDown.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.btnDown.Location = new System.Drawing.Point(603, 0);
			this.btnDown.Margin = new System.Windows.Forms.Padding(2);
			this.btnDown.Name = "btnDown";
			this.btnDown.Size = new System.Drawing.Size(77, 48);
			this.btnDown.TabIndex = 12;
			this.btnDown.Text = "下一页";
			this.btnDown.UseVisualStyleBackColor = true;
			this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.tableLayoutPanel2.ColumnCount = 10;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(200, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 10;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(680, 569);
			this.tableLayoutPanel2.TabIndex = 2;
			// 
			// frmZhuoTaiQuery
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(880, 617);
			this.Controls.Add(this.tableLayoutPanel2);
			this.Controls.Add(this.panBottom);
			this.Controls.Add(this.panLeftOuter);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmZhuoTaiQuery";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "桌台查询";
			this.Load += new System.EventHandler(this.frmZhuoTaiQuery_Load);
			this.panLeftOuter.ResumeLayout(false);
			this.panLeftBtn.ResumeLayout(false);
			this.panBottom.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panLeftOuter;
		private System.Windows.Forms.Panel panLeftBtn;
		private System.Windows.Forms.Button btnZTDown;
		private System.Windows.Forms.Button btnZTUp;
		private System.Windows.Forms.Panel panBottom;
		private System.Windows.Forms.Button btnDown;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Button btnUp;


	}
}